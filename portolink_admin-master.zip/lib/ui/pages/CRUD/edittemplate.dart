part of '../pages.dart';

class EditTemplate extends StatefulWidget {
  EditTemplate({Key key}) : super(key: key);

  @override
  _EditTemplateState createState() => _EditTemplateState();
}

class _EditTemplateState extends State<EditTemplate> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
