part of 'pages.dart';

class Requests extends StatefulWidget {
  Requests({Key key}) : super(key: key);

  @override
  _RequestsState createState() => _RequestsState();
}

class _RequestsState extends State<Requests> {
  @override
  Widget build(BuildContext context) {
    return Text('Request');
  }
}
