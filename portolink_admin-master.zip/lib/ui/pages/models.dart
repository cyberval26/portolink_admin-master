part of 'pages.dart';

class Admin {
  String uid = "", email = "";
  bool verified = false, loggedIn = false;

  Admin();
}
