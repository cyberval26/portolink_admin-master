package com.portolink.admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
